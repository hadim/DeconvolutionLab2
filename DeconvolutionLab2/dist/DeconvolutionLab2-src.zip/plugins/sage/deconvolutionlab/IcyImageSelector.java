package plugins.sage.deconvolutionlab;

import deconvolutionlab.PlatformImageSelector;

public class IcyImageSelector extends PlatformImageSelector {

	@Override
	public String getSelectedImage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isSelectable() {
		return false;
	}

}

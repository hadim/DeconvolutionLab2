import deconvolutionlab.Lab;
import deconvolutionlab.monitor.Monitors;
import ij.WindowManager;
import signal.RealSignal;
import signal.factory.Cube;

public class TestIJ {

	public static void main(String arg[]) {
		
		
		RealSignal im = new Cube(22, .1).generate(100, 100, 2);
		Lab.show(Monitors.createDefaultMonitor(), im, "im");
		Lab.show(Monitors.createDefaultMonitor(), im, "im1");
		Lab.show(Monitors.createDefaultMonitor(), im, "im2");
		
		int ids[] = WindowManager.getIDList();
		for(int i=0; i<ids.length; i++)
			System.out.println("" + i + " " + WindowManager.getImage(ids[i]));
		
	}
}

package deconvolutionlab;

public abstract class PlatformImageSelector {
	
	public abstract String getSelectedImage();
	public abstract boolean isSelectable();
}
